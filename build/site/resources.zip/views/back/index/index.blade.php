@extends('back.layout.main')
@section('content')
    <h1>admin</h1>

@stop