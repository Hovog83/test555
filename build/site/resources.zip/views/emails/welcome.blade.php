<h1>Welcome Please Login</h1>
<a href="{{ url('/login/active/') }}/{{$token}}">{{ url('/login/active/') }}/{{$token}}</a>