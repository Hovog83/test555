<h1>Welcome Please Login</h1>
<a href="{{ url('/password/reset/') }}/{{$token}}">{{ url('/password/reset/') }}/{{$token}}</a>