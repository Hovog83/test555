<?php 
 return 
 array (
  'test_sdsa_html' => '<p>page</p>

<p>&nbsp;</p>

<p>asd</p>

<p>asd</p>
',
  'est2asddasdas_html' => '<p>sad</p>
',
  'test3_html' => '<p>asdasd aa a a f</p>
',
); ?>