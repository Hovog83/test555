<?php 
 return 
 array (
  'test_sdsa_html' => '<p><u><em><strong>dsasdasda sad as asfd sad gsdfgtsf r sd gsfhg</strong></em></u></p>

<p><img alt="" src="/page/thumb_6808fc08965a1410d07c25f4e8a00fc3.jpg" /></p>
',
  'est2asddasdas_html' => '<p>sad</p>
',
  'test3_html' => '<p>asdasd aa a a f</p>
',
); ?>