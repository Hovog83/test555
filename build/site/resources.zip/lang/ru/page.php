<?php 
 return 
 array (
  'page' => 'page',
); 
?>