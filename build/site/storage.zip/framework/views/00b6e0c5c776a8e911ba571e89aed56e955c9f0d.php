<!-- Scripts -->
  <script src="<?php echo e(asset('/assets/front/assets/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/assets/front/assets/js/skel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('/assets/front/assets/js/util.js')); ?>"></script>
  <!--[if lte IE 8]><script src="<?php echo e(asset('/assets/front/assets/js/ie/respond.min.js')); ?>"></script><![endif]-->
  <script src="<?php echo e(asset('/assets/front/assets/js/main.js')); ?>"></script>
