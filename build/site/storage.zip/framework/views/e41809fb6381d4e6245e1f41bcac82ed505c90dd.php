<!DOCTYPE HTML>
<html>
  <head>
    <title>Phantom by HTML5 UP</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!--[if lte IE 8]><script src="<?php echo e(asset('/assets/front/assets/js/ie/html5shiv.js')); ?>"></script><![endif]-->
    <link rel="stylesheet" href="<?php echo e(asset('/assets/front/assets/css/main.css')); ?>" />
    <!--[if lte IE 9]><link rel="stylesheet" href="<?php echo e(asset('/assets/front/assets/css/ie9.css')); ?>" /><![endif]-->
    <!--[if lte IE 8]><link rel="stylesheet" href="<?php echo e(asset('/assets/front/assets/css/ie8.css')); ?>" /><![endif]-->
  </head>
