
<?php $__env->startSection('content'); ?>
    <h1>admin</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>